<template>

  <!-- <v-btn color="#FCEE21"  elevation="5" class="px-8 py-2  mr-4"  text="التالي" @click="props.callback()"/>
    <v-btn color="#101820"  elevation="5" class="px-8 py-2"  text="السابق" @click="props.submitBack()"/> -->


  <v-btn color="#FCEE21" elevation="5" class="px-8 mr-4 font-weight-black" @click="props.callback()">
    المزايا
  </v-btn>
  <v-btn color="#101820" elevation="5" class="px-8 font-weight-black" @click="props.submitBack()">
    إعادة
  </v-btn>


</template>

<script setup>
const props = defineProps({
  callback: {
    type: Function,
    required: true
  },
  submitBack: {
    type: Function,
    required: true
  }

})

</script>