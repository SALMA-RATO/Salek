<template>

  <v-btn color="#FCEE21" elevation="5" class="px-8 py-2" @click="props.callback()">

    <span class="font-weight-black">

      أبدأ

    </span>
  </v-btn>
</template>

<script setup>
const props = defineProps({
  callback: {
    type: Function,
    required: true
  }
})

</script>
