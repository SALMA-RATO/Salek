<template>
  <div class="footer-section text-center"
    style="height: 30vh; display: flex; flex-direction: column; justify-content: center; align-items: center;">

    <v-container>


      <v-row class="justify-center">
        <v-col cols="12" md="8" sm="8">
          <v-btn class="font-weight-bold text-body2" block>
            طلبة جامعات و مدارس حكومية
          </v-btn>

        </v-col>
        <v-col cols="12" md="4" sm="4">

          <v-btn class="font-weight-bold text-body2 " block>
            ذوي الهمم
          </v-btn>
        </v-col>
      </v-row>

      <v-row class="justify-center">
        <v-col cols="6" sm="6">
          <v-btn class="font-weight-bold text-body2" block>
            السن بين 60 و 69
          </v-btn>

        </v-col>
        <v-col cols="6" sm="6">

          <v-btn class="font-weight-bold text-body2" block>

            السن 70 وما فوق

          </v-btn>

        </v-col>
      </v-row>

      <v-row class="justify-center">
        <v-col cols="12" sm="12">

          <v-btn class="font-weight-bold" block>
            لا, أنا مش ضمن
            المجموعات دي

          </v-btn>

        </v-col>
      </v-row>
    </v-container>
  </div>
</template>





<script setup>
////
</script>


<!-- <style scoped>
.avatar-logo {
  position: fixed;
  width: 50vw;
  height: 50vh;
  margin:auto; /* Center the avatar container */
  margin-top: -40vh;
  z-index:1000  !important;
  
}
.progress {
  margin: auto; /* Add this line to center the progress bar */
  width: 375px; 
  height: 17px;
  border: 1px solid #FCEE21; 
  opacity: 0px; 
  padding: 5px;
  margin-top: 10px;
  border-radius: 10px;
  position: relative; /* Add this line */
  display: flex; /* Add this line */
  align-items: center; /* Add this line */
}
.progress-bar {
  background-color: #FCEE21; /* Adjust background color as needed */
  border-radius: 1px 1px 1px 1px; /* Adjust border-radius as needed */
  height: 20px;
  text-align: center;
  line-height: 20px;
  color: rgb(255, 255, 255);
  position: relative;
  left: 50%;
  transform: translateX(-50%);
  
}


.button {
  background-color: yellow;
  position: absolute;
  bottom: 20px; /* Add some space between the button and the bottom of the viewport */
  left: 50%;
  transform: translateX(-50%);
  padding: 10px 20px; /* Add some padding to the button */
  border-radius: 10px; 
}
.button-text {
  font-weight: bold; /* Make the text bold */
  margin: 0 10px; /* Add space before and after the text */
}

.custom-width {
  position: relative; /* Add relative positioning to the card */
  padding-top: 174px; /* Add padding to the card to make space for the avatar */
}
.card-content {
  padding-top: 10vh; /* Add padding to the card content to push it below the avatar */
}

</style> -->
