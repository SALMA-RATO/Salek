<template>


  <!-- 
      <h1 class="heading" style="font-family: Neo Sans Arabic; font-size: 20px; font-weight: 900px; line-height: 24px; text-align: center; color:#101820;">
  
      <p size="12px" >
          <br> 
          <b>
          اسمي سالك،وهوايتي اني أساعد
          <br>أصدقائي ركاب الخط الأخضر الثالث
          <br/>
          <br>تعرف اي إنك ممكن توفراي وقت وفلوس 
          <br>من خلال اشتراكات مترو القاهرة المختلفة؟
          تعالى نشوف إيه الاشتراك المناسب ليك....
          </b>

        </p>
        </h1> -->

  <!-- <h1 class="heading" style="font-family: Neo Sans Arabic; font-size: 20px; font-weight: 900px; line-height: 24px; text-align: center; color:#101820;">
  
      <p size="12px" >
          <br> 
          <b>
          اسمي سالك،وهوايتي اني أساعد
          <br>أصدقائي ركاب الخط الأخضر الثالث
          <br/>
          <br>تعرف اي إنك ممكن توفراي وقت وفلوس 
          <br>من خلال اشتراكات مترو القاهرة المختلفة؟
          تعالى نشوف إيه الاشتراك المناسب ليك....
          </b>

        </p>
        </h1> -->
  <!-- <h1 style="font-family: 'Neo Sans Arabic'; font-size: 20px; font-weight: 900; line-height: 24px; text-align: center;  padding: 20px;">
            <p size="12px" >

  <b>
    اسمي سالك،وهوايتي اني أساعد
    <br>
    أصدقائي ركاب الخط الأخضر الثالث
    <br>
    تعرف اي إنك ممكن توفراي وقت وفلوس
    <br>
    من خلال اشتراكات مترو القاهرة المختلفة؟
    <br>
    تعالى نشوف إيه الاشتراك المناسب ليك....
  </b>
  </p>
</h1> -->
  <p>
  <h1 class="heading"
    style=" font-size: 20px; font-weight: 900px; line-height: 24px; text-align: center; color:#101820;">
    <b><span style="font-size: 12px;">اسمي سالك،وهوايتي اني أساعد</span></b>
    <br>
    <b><span style="font-size: 12px;">أصدقائي ركاب الخط الأخضر الثالث</span></b>
    <br>
    <br>
    <b><span style="font-size: 12px;">تعرف/ي إنك ممكن توفراي وقت وفلوس</span></b>
    <br>
    <b> <span style="font-size: 12px;">من خلال اشتراكات مترو القاهرة المختلفة؟</span></b>
    <br>
    <br>
    <b> <span style="font-size: 12px;">تعالى نشوف إيه الاشتراك المناسب ليك</span></b>

  </h1>
  </p>
</template>



<script setup>
///
</script>

<!-- <style scoped>
  .avatar-logo {
    position: fixed;
    width: 50vw;
    height: 50vh;
    margin:auto; /* Center the avatar container */
    margin-top: -40vh;
    z-index:1000  !important;
    
  }
  .progress {
    margin: auto; /* Add this line to center the progress bar */
    width: 375px; 
    height: 17px;
    border: 1px solid #FCEE21; 
    opacity: 0px; 
    padding: 5px;
    margin-top: 10px;
    border-radius: 10px;
    position: relative; /* Add this line */
    display: flex; /* Add this line */
    align-items: center; /* Add this line */
  }
  .progress-bar {
    background-color: #FCEE21; /* Adjust background color as needed */
    border-radius: 1px 1px 1px 1px; /* Adjust border-radius as needed */
    height: 20px;
    text-align: center;
    line-height: 20px;
    color: rgb(255, 255, 255);
    position: relative;
    left: 50%;
    transform: translateX(-50%);
    
  }
  
  
  .button {
    background-color: yellow;
    position: absolute;
    bottom: 20px; /* Add some space between the button and the bottom of the viewport */
    left: 50%;
    transform: translateX(-50%);
    padding: 10px 20px; /* Add some padding to the button */
    border-radius: 10px; 
  }
  .button-text {
    font-weight: bold; /* Make the text bold */
    margin: 0 10px; /* Add space before and after the text */
  }
  
  .custom-width {
    position: relative; /* Add relative positioning to the card */
    padding-top: 174px; /* Add padding to the card to make space for the avatar */
  }
  .card-content {
    padding-top: 10vh; /* Add padding to the card content to push it below the avatar */
  }
  
  </style> -->