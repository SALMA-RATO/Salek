<template>
 
 <p class="subtitle-1  class=black-card pa-4">
    <b>
             الاشتراك بيوفر للركاب اللي بيستخدموا
            <br>
              بين المحطات دي 
              <span style="color: #fcee21; font-weight: bold;">  xxرحله </span>
              <span style="color: #fcee21; font-weight: bold;">  xx </span>
              المترو أكثر من
             <br>.
          بس  
          <span style="color: #fcee21; font-weight: bold;"> كارت المحفظه </span>

          ممكن يوفرلك وقت 
          <br>
          ومجهود كتيرز ممكن تشتريه من أي 
          <br>
          ماكينة أو شباك تذاكر علي الخط الاخضر
          <br>
           .الثالث اتعرف علي مزايا كارت المحفظة
           <br>
    </b>
         </p>

  </template>
  
  <script setup>
  // Add any necessary props or imports
  </script>
  
  <style scoped>
  .text-box {
    background-color: #2d3748; /* Dark background similar to the image */
    padding: 16px;
    border-radius: 8px;
    color: white;
    font-family: 'Tajawal', sans-serif; /* Arabic font similar to the image */
  }
  
  .main-text {
    font-size: 18px; /* Adjust font size */
    font-weight: 400;
    line-height: 1.5;
    margin-bottom: 8px;
  }
  
  .highlight {
    font-weight: 700; /* Bold text */
    color: #f4b400;   /* Yellowish color similar to the image */
  }
  
  .card-highlight {
    font-weight: 700;
    color: #fdd835; /* Slightly brighter yellow for "كارت المحفظة" */
  }

  .black-card {
  background-color: black; /* Set the background color to black */
  color: white; /* Text color to make it readable on a dark background */
  border-radius: 8px;
}
  </style>
  