<!-- <template>

    <div class="footer-section">
         
        <v-row class="justify-center">
               <v-col cols="6" sm="3">
                  <v-btn class="choice-btn" outlined block>  أقل من 4 رحلات </v-btn>
                </v-col>
               <v-col cols="6" sm="3">
                 <v-btn class="choice-btn" outlined block>   من 4 ل 7 رحلات  </v-btn>
                </v-col>
              </v-row>



              <v-row class="justify-center">

              <v-col cols="6" sm="3">
                <v-btn class="choice-btn" outlined block>   من 8 ل 11 رحلات  </v-btn>
               </v-col>
              <v-col cols="6" sm="3">
                 <v-btn class="choice-btn" outlined block> أكثر من 12 رحلة</v-btn>
               </v-col>
         </v-row>         
        
     </div>
    
          
    
    </template> -->
    
    <template>
        <div class="footer-section text-center" style="height: 25vh; display: flex; flex-direction: column; justify-content: center; align-items: center;">
          <div>
                  <!-- First row of buttons -->

            <v-row class="justify-center">
                <v-col cols="6" sm="6" >
                  
                    <v-btn class="choice-btn" outlined block>
                        <b>
                        أقل من 4 رحلات
                    </b>

                    </v-btn>
              </v-col>
              <v-col cols="6" sm="6" >
                

                <v-btn class="choice-btn" outlined block>
                    <b>
                    من 4 ل 7 رحلات
                </b>

                </v-btn>

              </v-col>
            </v-row>
          </div>


          <br/>
          
          <div>
            <v-row class="justify-center">
                <v-col cols="6" sm="6" >
                    <v-btn class="choice-btn" outlined block>
                        <b>
                        من 8 ل 11 رحلات
                    </b></v-btn>
                        
              </v-col>
              <v-col cols="6" sm="6" >
               
                <v-btn class="choice-btn" outlined block><b>
                    اكتر من 12 رحلة
                </b>

                </v-btn>
              </v-col>
            </v-row>
          </div>
        </div>
      </template>
          
           
    
    <script setup>
    ////
    </script>
    
    <!-- <style scoped>
    .avatar-logo {
      position: fixed;
      width: 50vw;
      height: 50vh;
      margin:auto; /* Center the avatar container */
      margin-top: -40vh;
      z-index:1000  !important;
      
    }
    .progress {
      margin: auto; /* Add this line to center the progress bar */
      width: 375px; 
      height: 17px;
      border: 1px solid #FCEE21; 
      opacity: 0px; 
      padding: 5px;
      margin-top: 10px;
      border-radius: 10px;
      position: relative; /* Add this line */
      display: flex; /* Add this line */
      align-items: center; /* Add this line */
    }
    .progress-bar {
      background-color: #FCEE21; /* Adjust background color as needed */
      border-radius: 1px 1px 1px 1px; /* Adjust border-radius as needed */
      height: 20px;
      text-align: center;
      line-height: 20px;
      color: rgb(255, 255, 255);
      position: relative;
      left: 50%;
      transform: translateX(-50%);
      
    }
    
    
    .button {
      background-color: yellow;
      position: absolute;
      bottom: 20px; /* Add some space between the button and the bottom of the viewport */
      left: 50%;
      transform: translateX(-50%);
      padding: 10px 20px; /* Add some padding to the button */
      border-radius: 10px; 
    }
    .button-text {
      font-weight: bold; /* Make the text bold */
      margin: 0 10px; /* Add space before and after the text */
    }
    
    .custom-width {
      position: relative; /* Add relative positioning to the card */
      padding-top: 174px; /* Add padding to the card to make space for the avatar */
    }
    .card-content {
      padding-top: 10vh; /* Add padding to the card content to push it below the avatar */
    }
    
    </style>
    
    
    
    
     -->