<template>
  <v-app>
    <v-main>
      <Mobile v-if="$vuetify.display.mobile">
        <template #page>
        </template>

      </Mobile>


      <Desktop v-else>
        <router-view />
      </Desktop>

    </v-main>
  </v-app>
</template>

<script setup>
import Desktop from './layouts/desktop.vue';
import Mobile from './layouts/mobile.vue'; 
</script>
