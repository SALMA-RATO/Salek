<template >
<v-img  cover  class="h-screen w-screen"
 src="@/assets/salikMobile.jpg">
 <v-slot name="page">
    <router-view />
</v-slot>
</v-img>

</template>

