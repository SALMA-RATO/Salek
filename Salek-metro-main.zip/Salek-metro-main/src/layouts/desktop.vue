<template>
<v-img cover  class="h-screen w-screen" src="@/assets/Salik app bg color V29.09.2024-07 (002).jpg">
    <v-slot />

</v-img>
</template>
<script setup>
///
</script>
<style scoped>

</style>