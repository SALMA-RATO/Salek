<template>

  <!-- <div class="progress">
  <div class="progress-bar" role="progressbar" style="width: 25%;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100">10%</div>
</div> -->
  <!-- <div class="h-screen d-flex justify-center align-center">  
          <v-img src="@/assets/logo.png" alt="Avatar"  class="avatar-logo" />


          <v-card v-bind="props" :elevation="isHovering ? 24 : 6"  class="pa-10 position-relative custom-width">
            <div class="card-content">
                    <Firstpage  v-if="pageIndex === 0" />
                    <SecPage    v-if="pageIndex === 1 " />
                    <Thirdpage  v-if="pageIndex === 2 "/>
                    <Fourthpage v-if="pageIndex === 3 "/>
            </div>
          </v-card>

         </div> -->

  <v-container>

    <!-- Card with avatar above -->
    <div class="card-container">
      <!-- Avatar fully visible above the card -->
      <div class="avatar-position" style="height: 100px; width: 100px;">
        <v-img src="@/assets/logo.png" alt="Avatar" class="avatar-logo" contain />
      </div>
      <!-- Card Content -->
      <v-card class="card-custom pa-12">
        <div class="card-content">
          <Firstpage v-if="pageIndex === 0" />
          <SecPage v-if="pageIndex === 1" />
          <Thirdpage v-if="pageIndex === 2" />
          <Fourthpage v-if="pageIndex === 3" />
        </div>
      </v-card>
    </div>
  </v-container>


  <v-card class="card-choices pa-0 bg-transparent  " elevation="0">

    <div class="card-choices">
      <ThirdPageChoices v-if="pageIndex === 2" :callback="submit1" :submitBack="submitBack" />
      <SecPageChoices v-if="pageIndex === 1" :callback="submit1" :submitBack="submitBack" />

    </div>
  </v-card>


  <!-- <div class="h-screen d-flex justify-center align-center">  

<ThirdPageChoices   v-if="pageIndex === 2" :callback="submit1" :submitBack="submitBack" />
</div> -->



  <v-footer class="position-fixed bottom-0 left-0 w-100 bg-transparent d-flex flex-row justify-center align-center  "
    elevation="0">
    <FirstpageAction v-if="pageIndex === 0" :callback="submit1" />
    <SecPageAction v-if="pageIndex === 1" :callback="submit1" :submitBack="submitBack" />
    <ThirdPageAction v-if="pageIndex === 2" :callback="submit1" :submitBack="submitBack" />
    <FourthpageAction v-if="pageIndex === 3" :callback="submit1" :submitBack="submitBack" />
    <!-- <SecPageChoices  v-if="pageIndex === 1" :callback="submit1" :submitBack="submitBack" /> 
    <ThirdPageChoices   v-if="pageIndex === 2" :callback="submit1" :submitBack="submitBack" />   -->
  </v-footer>


</template>



<script setup>
import Firstpage from '@/components/firstpage.vue';
import SecPage from '@/components/secPage.vue';
import FirstpageAction from '@/components/firstpageAction.vue';
import SecPageAction from '@/components/secPageAction.vue';
import ThirdPageAction from '@/components/thirdPageAction.vue';
import Thirdpage from '@/components/thirdpage.vue';
import FourthpageAction from '@/components/fourthpageAction.vue';
import Fourthpage from '@/components/fourthpage.vue';

import { ref } from 'vue'
import SecPageChoices from '@/components/secPageChoices.vue';
import ThirdPageChoices from '@/components/thirdPageChoices.vue';

// let isHovering = ref(false)


const pageIndex = ref(0)
const submit1 = () => {
  pageIndex.value === 3 ? alert('finish') : pageIndex.value++
}

const submitBack = () => {
  pageIndex.value > 0 ? pageIndex.value-- : alert("No more backs")
}




</script>

<!-- <style scoped>
.avatar-logo {
  position: fixed;
  width: 50vw;
  height: 50vh;
  margin:auto; /* Center the avatar container */
  margin-top: -40vh;
  z-index:1000  !important;
  
}
.progress {
  margin: auto; /* Add this line to center the progress bar */
  width: 375px; 
  height: 17px;
  border: 1px solid #FCEE21; 
  opacity: 0px; 
  padding: 5px;
  margin-top: 10px;
  border-radius: 10px;
  position: relative; /* Add this line */
  display: flex; /* Add this line */
  align-items: center; /* Add this line */
}
.progress-bar {
  background-color: #FCEE21; /* Adjust background color as needed */
  border-radius: 1px 1px 1px 1px; /* Adjust border-radius as needed */
  height: 20px;
  text-align: center;
  line-height: 20px;
  color: rgb(255, 255, 255);
  position: relative;
  left: 50%;
  transform: translateX(-50%);
  
}


.button {
  background-color: yellow;
  /* position: absolute; */
  /* bottom: 20px; 
  left: 50%;
  transform: translateX(-50%); */
  padding: 10px 20px; /* Add some padding to the button */
  border-radius: 10px; 
}


.button-text {
  font-weight: bold; /* Make the text bold */
  margin: 0 10px; /* Add space before and after the text */
}

.custom-width {
  position: relative; /* Add relative positioning to the card */
  padding-top: 174px; /* Add padding to the card to make space for the avatar */
}
.card-content {
  padding-top: 10%; /* Add padding to the card content to push it below the avatar */
  
}

</style> -->


<style scoped>
.card-container {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-start;
  margin-top: 30px;
}

.avatar-position {
  position: relative;
  top: 70px;
  /* Adjust this value to control how far above the card the avatar appears */
  z-index: 1;
  /* Make sure the avatar is on top of the card */
  object-fit: cover;
  /* Ensures the whole image is visible within the avatar */
}

.avatar-logo {


  object-fit: cover;
  /* or contain */
  z-index: 1000 !important;


}

.card-choices {
  background: local;
}

.card-custom {
  width: 300px;
  min-height: 200px;
  margin-top: 40px;
  /* Creates space for the avatar */
  border-radius: 16px;
  /* Default card radius */
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
  text-align: center;
  padding: 20px;
}





.v-footer {
  background-color: transparent;
  padding: 40px;
}
</style>